package com.example.demo.repository;

import org.springFramework.data.jpa.repository.JpaRepository;
import com.example.demo.modele.Categorie;

public interface CategorieRepository extends JpaRepository<Categorie, Long> {
}
