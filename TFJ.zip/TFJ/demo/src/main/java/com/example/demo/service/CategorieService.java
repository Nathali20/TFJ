package com.example.demo.service;

import com.example.demo.modele.Categorie;

import java.util.List;

public interface CategorieService {

    Categorie creer(Categorie categorie);

    List<Categorie> lire();

    Categorie modifier(Long id, Categorie categorie);

    String supprimer(Long id);
}
