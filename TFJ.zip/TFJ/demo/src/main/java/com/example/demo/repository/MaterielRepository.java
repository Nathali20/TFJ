package com.example.demo.repository;

import com.example.demo.modele.Materiel;

import org.springFramework.data.jpa.repository.JpaRepository;

public interface MaterielRepository extends JpaRepository<Materiel, Long>{
}
