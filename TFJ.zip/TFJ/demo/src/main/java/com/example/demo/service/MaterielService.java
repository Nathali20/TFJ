package com.example.demo.service;

import com.example.demo.modele.Materiel;

import java.util.List;

public interface MaterielService {

    Materiel creer(Materiel produit);

    List<Materiel> lire();

    Materiel modifier(Long id, Materiel materiel);

    String supprimer(Long id);
}
