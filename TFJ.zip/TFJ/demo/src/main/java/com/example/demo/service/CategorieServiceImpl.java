package com.example.demo.service;

import com.example.demo.modele.Categorie;
import com.example.demo.repository.CategorieRepository;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor

public class CategorieServiceImpl implements CategorieService{
    private final CategorieRepository categorieRepository;

    public CategorieServiceImpl(CategorieRepository categorieRepository) {
        this.categorieRepository = categorieRepository;
    }

    @Override
    public Categorie creer(Categorie categorie) {
        return categorieRepository.save(categorie);
    }

    @Override
    public List<Categorie> lire() {
        return categorieRepository.findAll();
    }

    @Override
    public Categorie modifier(Long id, Categorie categorie) {
        return categorieRepository.findById(id)
                .map(p-> {
                    p.setPrix(categorie.getPrix());
                    p.setNom(categorie.getNom());
                    p.setDescription(categorie.getDescription());
                    return categorieRepository.save(p);
                }).orElseThrow(() -> new RuntimeException("categorie non trouvé"));
    }

    @Override
    public String supprimer(Long id) {
        categorieRepository.deleteById(id);
        return "categorie supprimé";
    }

}
