package com.example.demo.service;

import com.example.demo.modele.Materiel;
import com.example.demo.repository.MaterielRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class MaterielServiceImpl implements MaterielService {

    private final MaterielRepository materielRepository;

    public MaterielServiceImpl(MaterielRepository materielRepository) {
        this.materielRepository = materielRepository;
    }

    @Override
    public Materiel creer(Materiel materiel) {
        return materielRepository.save(materiel);
    }

    @Override
    public List<Materiel> lire() {
        return materielRepository.findAll();
    }

    @Override
    public Materiel modifier(Long id, Materiel materiel) {
        return materielRepository.findById(id)
                .map(p-> {
                    p.setPrix(materiel.getPrix());
                    p.setNom(materiel.getNom());
                    p.setDescription(materiel.getDescription());
                    return materielRepository.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String supprimer(Long id) {
        materielRepository.deleteById(id);
        return "produit supprimé";
    }
}
